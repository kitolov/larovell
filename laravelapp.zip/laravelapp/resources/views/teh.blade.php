<?php
use yii\bootstrap5\ActiveForm;
use yii\bootstrap5\Html;
use yii\captcha\Captcha;
?>
<div class="site-contact">
<head>
  <body>
    @foreach($posts as $post)
    {{$post->name}}
    @endforeach
    <h1>larawel говно</h1>
</body> 
</head>