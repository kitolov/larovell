<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>

body { 
  margin: 0;
  font-family: Arial, sans-serif;
  background-color: #98FB98

}

header {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  flex-wrap: wrap;
  background-color: #FFEB3B;
  padding: 20px 10px;
}

.wrap-logo {
  display: flex;
  align-items: center;
 
}

header a {
  color: #212121;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  border-radius: 4px;
}

header a.logo {
  font-size: 25px;
  font-weight: bold;
}

header a:hover {
  background-color: #FBC02D;
  color: #212121;
}

header a.active {
  background-color: #FBC02D;
}

nav {
  display: flex;
  align-items: center;
} 
</style>
</head>
<body>

<header>
  <div class="wrap-logo">
  <a href="/h" class="logo">АПТ</a>
  </div>
  <nav>
    <a href="/con">Контакты</a>
    <a href="/i">И-20-1</a>
    <a href="/a">Професии</a>
    <a href="/s">S</a>
    <a href="/p">P</a>
  </nav>
</header>
    <center><h1>АПТ</h1>
    <h2>Ангарский Политехнический Техникум</h2>
    <div style="background-color:#FBCEB1;float: left;width: 200px;padding: 50px;height: 400px"><img src = http://www.aptangarsk.ru/wp-content/uploads/2022/11/image1.jpeg width = "220" height = "220">ТОП-100 регионального конкурса «Моя карьера»</div>
<div style="background-color:#FDD9B5;float: left;width: 200px;padding: 50px;height: 400px"><img src = http://www.aptangarsk.ru/wp-content/uploads/2022/11/3.jpeg width = "220" height = "220">Вступай в команду ИНК!</div>
<div style="background-color:#B5B8B1;float: left;width: 200px;padding: 50px;height: 400px"><img src = http://www.aptangarsk.ru/wp-content/uploads/2022/11/%D0%94%D0%9A-%D0%9D%D0%B5%D1%84%D1%82%D0%B5%D1%85%D0%B8%D0%BC.jpg width = "220" height = "220">
 Наш дом Россия</div>
 </center>
</body>
</html>