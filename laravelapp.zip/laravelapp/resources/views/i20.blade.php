<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<style>
}
body{
    background-color: #98FB98
}
body { 
  margin: 0;
  font-family: Arial, sans-serif;
  background-color: #98FB98

}

header {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  flex-wrap: wrap;
  background-color: #FFEB3B;
  padding: 20px 10px;
}

.wrap-logo {
  display: flex;
  align-items: center;
 
}

header a {
  color: #212121;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  border-radius: 4px;
}

header a.logo {
  font-size: 25px;
  font-weight: bold;
}

header a:hover {
  background-color: #FBC02D;
  color: #212121;
}

header a.active {
  background-color: #FBC02D;
}

nav {
  display: flex;
  align-items: center;
} 
</style>
</head>
<body>
<header>
  <div class="wrap-logo">
  <a href="/h" class="logo">АПТ</a>
  </div>
  <nav>
    <a href="/con">Контакты</a>
    <a href="/i">И-20-1</a>
    <a href="/a">Професии</a>
  </nav>
</header>
    </div>
<div style="background-color:#FBCEB1;float: left;width: 200px;padding: 50px;height: 400px"><img src = https://sun9-59.userapi.com/impg/SuieClhhP1pepWBoS53sSZQebBoGluaWi3j31A/4JuHG0Wggs0.jpg?size=810x1080&quality=96&sign=f8e06a329bbf818c644a4326b130faa6&type=album width = "120" height = "120">Чахлов Никита</div>
</div>
<div style="background-color:#FBCEB1;float: left;width: 200px;padding: 50px;height: 400px"><img src = https://sun9-18.userapi.com/impg/9IJot8Q8s4GUO6j5sifSE_Do8LLmGvE_hpHokw/Ll0WxZdcRBU.jpg?size=720x1080&quality=96&sign=b4e3295549a9381d06839e557ebbeac5&type=album width = "120" height = "120">Крымов Ярослав</div>
</div>
<div style="background-color:#FBCEB1;float: left;width: 200px;padding: 50px;height: 400px"><img src = https://sun9-78.userapi.com/impg/Qcp-dz3L4TnfvtZM-oBtm1DrOZsBmGpxQ4fD5Q/phVUjiyaxF0.jpg?size=667x1080&quality=95&sign=d23ddb3357ff1e6a1334f530e3cf4fdc&c_uniq_tag=fOROqq0i1nCOk0e0phtvcXDzNw_abGVwmVDYuh-M2T8&type=album width = "120" height = "120">Гавриш Михаил</div>
</div>
<div style="background-color:#FBCEB1;float: left;width: 200px;padding: 50px;height: 400px"><img src = https://sun9-68.userapi.com/impg/x-MGEVspsDQAl3rSU6rILB2TC1JVoaGBtcmlaA/PRYaG7hJ0io.jpg?size=810x1080&quality=95&sign=94ec79ba19b402b89a7853cfb0eac71a&type=album width = "120" height = "120">Скоркин Ян</div>
</div>
<div style="background-color:#FBCEB1;float: left;width: 200px;padding: 50px;height: 400px"><img src = https://sun1.sibirix.userapi.com/impg/2dsAxaok0F0ZofoMkZlbGb-noAALJD-tuSCokg/F72m5v8bdBU.jpg?size=834x1080&quality=95&sign=20643d12890a7cf12ba5366590f4c334&type=album width = "120" height = "120">Рудакова Юля</div>
<a href = "stud">!student!</a>
<a href = "prep">!prepod!</a>
</body>
</html>
