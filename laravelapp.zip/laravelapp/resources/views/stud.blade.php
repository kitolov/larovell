<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table border = "1">
    <thead>
        <tr>
    <th>id</th>
    <th>Имя</th>
<th>фамилия</th>
<th>деньрождения</th>
<th>рост</th>
  <th>срендний балл</th>
  </tr>
</thead>
<tbody>
@foreach($posts as $post)
<tr>
    <td>{{$post->id}}</td>
    <td>{{$post->name}}</td>
    <td>{{$post->fam}}</td>
    <td>{{$post->Den_ro}}</td>
    <td>{{$post->rost}}</td>
    <td>{{$post->sred_ball}}</td>
</tr>
@endforeach
</tbody>
</table>
</body>
</html>