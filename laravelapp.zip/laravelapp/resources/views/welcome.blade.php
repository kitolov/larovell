<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
body {
background-color: #98FB98
}
header {
 display: block; /* Для старых браузеров */
 height: 405px; /* Высота шапки */
 backcolor: red; no-repeat center bottom;
}
</style>

</head>
<body>
<header>
 <div class="header-bg">
  <img src="images/header-title.png" alt="Как поймать льва в пустыне">
 </div>
</header>
    <center><h1>АПТ</h1>
    <h2>Ангарский Политехнический Техникум</h2>
<div style="background-color:#FBCEB1;float: left;width: 200px;padding: 50px;height: 400px"><img src = http://www.aptangarsk.ru/wp-content/uploads/2022/11/image1.jpeg width = "220" height = "220">ТОП-100 регионального конкурса «Моя карьера»</div>
<div style="background-color:#FDD9B5;float: left;width: 200px;padding: 50px;height: 400px"><img src = http://www.aptangarsk.ru/wp-content/uploads/2022/11/3.jpeg width = "220" height = "220">Вступай в команду ИНК!</div>
<div style="background-color:#B5B8B1;float: left;width: 200px;padding: 50px;height: 400px"><img src = http://www.aptangarsk.ru/wp-content/uploads/2022/11/%D0%94%D0%9A-%D0%9D%D0%B5%D1%84%D1%82%D0%B5%D1%85%D0%B8%D0%BC.jpg width = "220" height = "220">
 Наш дом Россия</div>
 </center>
</body>
</html>