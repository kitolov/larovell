<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class teh extends Model
{
    use HasFactory;
    public function tehsModel(){
        return DB::table('tehs')->select('*')->get();
    }
}