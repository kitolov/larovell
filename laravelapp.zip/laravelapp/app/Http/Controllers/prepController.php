<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\prep;
class prepController extends Controller
{
    public function prep(){
        $posts = DB::table('preps')->select('*')->get();
        return view('prep',compact('posts'));
}}
