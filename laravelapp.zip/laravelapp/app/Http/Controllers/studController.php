<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\stud;
class studController extends Controller
{
    public function stud(){
    $posts = DB::table('studs')->select('*')->get();
    return view('stud',compact('posts'));
}}
