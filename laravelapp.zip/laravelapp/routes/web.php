<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\studController;



/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});

Route::get('/i', function () {
    return view('i20');
});

Route::get('/h', function () {
    return view('home');
});

Route::get('/con', function () {
    return view('contact');
});

Route::get('/s', function () {
    return view('stud');
});
Route::get('/p', function () {
    return view('prep');
});
Route::get('/a', function () {
    return view('about');
});
Route::get('stud',function(){
    $posts = App\Models\stud::all();
    return view('stud', compact('posts')); 
}); 
Route::get('prep',function(){
    $posts = App\Models\prep::all();
    return view('prep', compact('posts')); 
}); 
    