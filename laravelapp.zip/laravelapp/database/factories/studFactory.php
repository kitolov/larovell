<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\stud>
 */
class studFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            
            'name'=>fake()->firstname(),
            'fam'=>fake()->lastname(),
            'Den_ro'=>fake()->unique()->dateTimeBetween($startDate= '2000-01-01',$endDate='2005-01-01')->format('Y-m-d'),
            'rost'=>mt_rand(140,210),
            'sred_ball'=>mt_rand(2.0,5.0),
        ];
    }
}
