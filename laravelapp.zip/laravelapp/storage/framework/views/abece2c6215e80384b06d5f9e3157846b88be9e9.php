<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table border = "1">
    <thead>
        <tr>
    <th>id</th>
    <th>Имя</th>
<th>фамилия</th>
<th>деньрождения</th>
<th>рост</th>
  <th>Номер группы</th>
  </tr>
</thead>
<tbody>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($post->id); ?></td>
    <td><?php echo e($post->name); ?></td>
    <td><?php echo e($post->fam); ?></td>
    <td><?php echo e($post->Den_ro); ?></td>
    <td><?php echo e($post->rost); ?></td>
    <td><?php echo e($post->nomer_kursa); ?></td>
	
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</body>
</html><?php /**PATH /home/kitolow/laravelapp/resources/views/prep.blade.php ENDPATH**/ ?>